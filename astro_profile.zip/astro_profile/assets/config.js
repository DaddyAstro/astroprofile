const config = {
    
    USERNAME: "astro ✡#1258",
    
    PICTURE: "assets/img/profile_picture.png",

    DESCRIPTION: "Professional Anomic Player",

    BADGES: [
        /*{ id: "Nitro Sub", image: "assets/img/nitro_sub.svg" },*/
    ],

    PROJECTS: [
        { id: "project-1", image: "assets/img/placeholder1.png", link: "", name: "Project 1" },
        { id: "project-2", image: "assets/img/placeholder2.png", link: "", name: "Project 2" },
    ],

    SOCIALS: [
        { class_name: "fab fa-github", link: "" },
        { class_name: "fab fa-instagram", link: "" },
    ],
    /*
    * fa-github is like a fa-youtube, fa-instagram, fa-twitter etc.
    */

}

